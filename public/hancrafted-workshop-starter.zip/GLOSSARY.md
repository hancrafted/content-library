# hancrafted workshop starter

Starter repo for the hancrafted workshop.

## Language

**hancrafted**:
The homepage for Han, at hancrafted.net, containing visual episodes for AI enablement.
Guide URL: `https://hancrafted.net/guides/setup-ai-agent-and-starter-folder/`
