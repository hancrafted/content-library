---
name: hancrafted-check-setup
description: Check workshop readiness by comparing the copied skill folders and local-markdown setup, then open the hancrafted Guide with the results. Use when checking whether this starter folder is ready.
argument-hint: "[host, e.g. localhost:3002]"
---

# hancrafted-check-setup

Run the steps in order. Each step ends on its completion criterion; report every mismatch, fixing nothing unless the user asks.

Say one line in the conversation as each step starts and one as each item or group of items resolves (`✓ skills 27/27`, `✗ GLOSSARY-MAP.md exists`), so the user sees progress while the checks run.

Optional argument: a host to open instead of the `hancrafted` origin, e.g. `localhost:3002`. It replaces only the scheme and host; the Guide path, query and fragment stay. A bare host gets `http://`.

## 1. Skills

The starter folder ships a copy of each skill in `.agents/skills/` and `.claude/skills/`.

List the skill directory names in both locations. The sets must be non-empty and identical, and each directory must contain `SKILL.md`. For every name, compare the complete recursive set of relative file paths and each file's raw bytes. Include dotfiles and supporting files, not just `SKILL.md`; missing, extra or changed files fail that skill.

Done when every name from either location is marked pass or fail, with the missing directory, missing `SKILL.md` or differing relative file paths named for each failure. Pass only when every pair contains exactly the same files with byte-identical contents.

## 2. Repo setup

The repo follows the local markdown setup when every item holds:

- No git remote points at GitHub (no `.git`, or `git remote -v` shows no github.com host).
- `GLOSSARY.md` is the only glossary at the root: no `GLOSSARY-MAP.md`, no legacy `CONTEXT.md` / `CONTEXT-MAP.md`.
- `docs/agents/issue-tracker.md` describes issues as files under `.scratch/<feature>/`.
- `docs/agents/triage-labels.md` maps the five default labels to themselves: `needs-triage`, `needs-info`, `ready-for-agent`, `ready-for-human`, `wontfix`.
- `docs/agents/domain.md` exists.
- `AGENTS.md` holds the `## Agent skills` block with Issue tracker, Triage labels and Domain docs sub-sections.
- `CLAUDE.md` contains the `@AGENTS.md` reference.

Done when each item is marked pass or fail with the evidence (file and line).

## 3. Guide link

Start only once step 1 and step 2 have each finished with every item marked pass or fail. Set two flags from those results:

- `skills`: `true` when step 1 found non-empty matching skill sets, each with `SKILL.md` and byte-identical files in both locations, else `false`.
- `local-setup`: `true` when every step 2 item passed, else `false`.

Build the link: the Guide URL from the `hancrafted` entry in `GLOSSARY.md` (scheme and host swapped for the argument when given), then `?skills=<flag>&local-setup=<flag>#your-terminal--overview`. Flags are lowercase `true` / `false`, in that order; the link carries nothing else (no paths, usernames, machine details, file names).

Open it in the user's default browser, also when a flag is `false` (the page shows what is missing). Quote the link, because an unquoted `&` splits the command and drops `local-setup`:

- macOS: `open "<link>"`
- Linux: `xdg-open "<link>"`
- Windows: `start "" "<link>"`

Done when the command exits 0, or, if it fails, the full link is printed. Finish with the step 1 and 2 results as one pass/fail summary.
